package com.nibm.pharmagomadproject.customer;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.nibm.pharmagomadproject.R;

import java.util.ArrayList;
import java.util.List;

public class MedicineListActivity extends AppCompatActivity {

    public static final String EXTRA_MODE     = "mode";     // "search" | "category" | "pharmacy"
    public static final String EXTRA_TITLE    = "title";
    public static final String EXTRA_QUERY    = "query";

    private LinearLayout medicineListContainer;
    private EditText etSearch;
    private ImageView btnClearSearch;
    private TextView tvScreenTitle;
    private String mode = "search";

    // Static sample data — Firebase eka connect karala real data ganna
    private final List<Medicine> allMedicines = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_medicine_list);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        medicineListContainer = findViewById(R.id.medicineListContainer);
        etSearch              = findViewById(R.id.etSearch);
        btnClearSearch        = findViewById(R.id.btnClearSearch);
        tvScreenTitle         = findViewById(R.id.tvScreenTitle);

        // Back
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Intent extras
        mode = getIntent().getStringExtra(EXTRA_MODE) != null
                ? getIntent().getStringExtra(EXTRA_MODE) : "search";
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String query = getIntent().getStringExtra(EXTRA_QUERY);

        if (title != null) tvScreenTitle.setText(title);

        // Populate sample data
        loadSampleData();

        // Search mode — pre-fill query
        if ("search".equals(mode) && query != null && !query.isEmpty()) {
            etSearch.setText(query);
            etSearch.setSelection(query.length());
            filterMedicines(query);
        } else {
            // Category or pharmacy mode — show filtered list
            filterMedicines(query != null ? query : "");
        }

        // Live search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int i, int b, int c) {
                btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                filterMedicines(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Clear button
        btnClearSearch.setOnClickListener(v -> {
            etSearch.setText("");
            btnClearSearch.setVisibility(View.GONE);
        });

        // Keyboard search action
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                filterMedicines(etSearch.getText().toString());
                return true;
            }
            return false;
        });
    }

    private void loadSampleData() {
        // Sample medicines — Firebase ekata connect karaddi mee replace wenawa
        allMedicines.add(new Medicine("Paracetamol 500mg",    "Pain relief",   "OTC",          40,  "all"));
        allMedicines.add(new Medicine("Panadol Extra",         "Pain relief",   "OTC",          55,  "all"));
        allMedicines.add(new Medicine("Amoxicillin 500mg",     "Antibiotic",    "Prescription", 85,  "rx"));
        allMedicines.add(new Medicine("Metformin 500mg",       "Diabetes",      "Prescription", 35,  "chronic"));
        allMedicines.add(new Medicine("Vitamin C 1000mg",      "Supplement",    "OTC",          120, "vitamins"));
        allMedicines.add(new Medicine("Vitamin D3 1000IU",     "Supplement",    "OTC",          180, "vitamins"));
        allMedicines.add(new Medicine("Band-Aid Pack",         "First Aid",     "OTC",          250, "firstaid"));
        allMedicines.add(new Medicine("Antiseptic Solution",   "First Aid",     "OTC",          320, "firstaid"));
        allMedicines.add(new Medicine("Eye Drops (Refresh)",   "Eye care",      "OTC",          450, "eyecare"));
        allMedicines.add(new Medicine("Colgate Sensitive",     "Dental",        "OTC",          380, "dental"));
        allMedicines.add(new Medicine("Baby Cetirizine Syrup", "Baby care",     "OTC",          290, "baby"));
        allMedicines.add(new Medicine("Ibuprofen 400mg",       "Pain relief",   "OTC",          65,  "otc"));
        allMedicines.add(new Medicine("Antacid Tablets",       "Gastric",       "OTC",          95,  "otc"));
        allMedicines.add(new Medicine("Omeprazole 20mg",       "Gastric",       "Prescription", 75,  "rx"));
        allMedicines.add(new Medicine("Atorvastatin 10mg",     "Cholesterol",   "Prescription", 120, "chronic"));
    }

    private void filterMedicines(String query) {
        medicineListContainer.removeAllViews();

        List<Medicine> filtered = new ArrayList<>();
        String q = query.toLowerCase().trim();

        for (Medicine m : allMedicines) {
            boolean matchesQuery = q.isEmpty()
                    || m.name.toLowerCase().contains(q)
                    || m.category.toLowerCase().contains(q);

            boolean matchesMode = true;
            if ("category".equals(mode)) {
                // EXTRA_QUERY holds category key e.g. "rx", "vitamins"
                String catKey = getIntent().getStringExtra(EXTRA_QUERY);
                if (catKey != null) matchesMode = m.categoryKey.equals(catKey);
            }

            if (matchesQuery && matchesMode) filtered.add(m);
        }

        if (filtered.isEmpty()) {
            // Empty state
            TextView empty = new TextView(this);
            empty.setText("No medicines found for \"" + query + "\"");
            empty.setTextColor(getResources().getColor(R.color.pg_sub, null));
            empty.setTextSize(13);
            empty.setPadding(0, 48, 0, 0);
            empty.setGravity(android.view.Gravity.CENTER);
            empty.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            medicineListContainer.addView(empty);
            return;
        }

        tvScreenTitle.setText(filtered.size() + " result" + (filtered.size() == 1 ? "" : "s") + " found");

        LayoutInflater inflater = LayoutInflater.from(this);
        for (Medicine m : filtered) {
            View card = inflater.inflate(R.layout.item_medicine_card, medicineListContainer, false);
            ((TextView) card.findViewById(R.id.tvMedicineName)).setText(m.name);
            ((TextView) card.findViewById(R.id.tvMedicineCategory))
                    .setText(m.category + " · " + m.type);
            ((TextView) card.findViewById(R.id.tvMedicinePrice))
                    .setText("Rs. " + m.price);

            // Card click → MedicineDetailsActivity
            card.setOnClickListener(v -> {
                Intent intent = new Intent(this, MedicineDetailsActivity.class);
                intent.putExtra("medicine_name", m.name);
                startActivity(intent);
            });

            // Add to cart button
            card.findViewById(R.id.btnAddToCartCard).setOnClickListener(v -> {
                Toast.makeText(this, m.name + " added to cart!",
                        Toast.LENGTH_SHORT).show();
            });

            medicineListContainer.addView(card);
        }
    }

    // Simple data class
    static class Medicine {
        String name, category, type, categoryKey;
        int price;
        Medicine(String name, String category, String type, int price, String categoryKey) {
            this.name = name; this.category = category; this.type = type;
            this.price = price; this.categoryKey = categoryKey;
        }
    }
}
